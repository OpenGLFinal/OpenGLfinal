#pragma once

class Alpha_light
{
public:
	//����
	int x[5];
	int z[5];

	//�Լ�
	void light_draw(int crash1, int crash2, int crash3, int crash4, int crash5);
};