#pragma once
#define _CRT_SECURE_NO_WARNINGS

#include "stdafx.h"
#include <GL/freeglut.h>
#include <gl/glut.h> 
#include <time.h>
#include <iostream>
#include <math.h>
#include <stdlib.h>
#include <fstream>
#include "Sound.h"


using namespace std;

#define map_length 20